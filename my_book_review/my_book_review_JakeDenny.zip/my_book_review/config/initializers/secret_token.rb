# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
MyBookReview::Application.config.secret_token = '329947cbbbdf56968bc9c1790aa04d7caae61ff011c75f11f3d97aa743b0f0ebdfb6581375bbfc095d049c9e5da089ada5c3f9b3a5a9ade06e1cc1d0a9923fae'
